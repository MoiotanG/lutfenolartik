package com.example.akillikamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.view.HapticFeedbackConstants
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var autoCapture: CheckBox

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK

    private val executor = Executors.newSingleThreadExecutor()
    private val engine = GuidanceEngine()
    private var lastCaptureMs = 0L
    private var wasReady = false

    private val detector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else Toast.makeText(this, "Kamera izni gerekli", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        autoCapture = findViewById(R.id.autoCapture)

        findViewById<Button>(R.id.captureButton).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.flipButton).setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            startCamera()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            imageCapture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(executor) { proxy ->
                val media = proxy.image
                if (media == null) { proxy.close(); return@setAnalyzer }
                val rot = proxy.imageInfo.rotationDegrees
                val w = (if (rot % 180 == 0) proxy.width else proxy.height).toFloat()
                val h = (if (rot % 180 == 0) proxy.height else proxy.width).toFloat()
                val mirrored = lensFacing == CameraSelector.LENS_FACING_FRONT

                detector.process(InputImage.fromMediaImage(media, rot))
                    .addOnSuccessListener { faces ->
                        val b = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                            ?.boundingBox
                        val box = b?.let {
                            val l = it.left / w; val r = it.right / w
                            if (mirrored) RectF(1f - r, it.top / h, 1f - l, it.bottom / h)
                            else RectF(l, it.top / h, r, it.bottom / h)
                        }
                        runOnUiThread { onFace(box) }
                    }
                    .addOnCompleteListener { proxy.close() }
            }

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, selector, preview, imageCapture, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onFace(box: RectF?) {
        val cam = camera ?: return
        val zs = cam.cameraInfo.zoomState.value ?: return
        val maxZoom = min(zs.maxZoomRatio, 4f)
        val g = engine.update(box, zs.zoomRatio, zs.minZoomRatio, maxZoom)
        overlay.setGuidance(g)

        g.zoomTo?.let { cam.cameraControl.setZoomRatio(it) }

        if (g.ready && !wasReady) overlay.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
        wasReady = g.ready

        val now = SystemClock.elapsedRealtime()
        if (g.ready && autoCapture.isChecked && now - lastCaptureMs > 4000) {
            lastCaptureMs = now
            takePhoto()
        }
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AK_$name")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AkilliKamera")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        capture.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    Toast.makeText(this@MainActivity, "Fotoğraf kaydedildi", Toast.LENGTH_SHORT).show()
                }
                override fun onError(e: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_LONG).show()
                }
            })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        detector.close()
    }
}
