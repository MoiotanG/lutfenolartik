package com.example.akillikamera

import android.graphics.RectF
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.hypot

data class Guidance(
    val face: RectF?,          // normalize (0..1) yüz kutusu
    val targetX: Float,
    val targetY: Float,
    val message: String,
    val aligned: Boolean,      // nokta ile yüz hizalı mı
    val ready: Boolean,        // hizalı + zoom tamam: çekime hazır
    val zoomTo: Float?         // null değilse bu zoom oranına git
)

class GuidanceEngine {
    // Hedef nokta: kadrajın merkezine yakın, biraz yukarıda (göz hizası).
    // Zoom merkezden yapıldığı için yüz merkezde kalırsa zoom sonrası da kadrajda kalır.
    private val targetX = 0.5f
    private val targetY = 0.45f

    private val enterThreshold = 0.07f   // hizalanmak için
    private val keepThreshold = 0.12f    // zoom sırasında hizayı kaybetmemek için
    private val targetFaceHeight = 0.30f // yüz, kadraj yüksekliğinin ~%30'u olsun
    private val holdMs = 500L

    private var alignedSince = 0L

    fun update(face: RectF?, zoom: Float, minZoom: Float, maxZoom: Float): Guidance {
        if (face == null) {
            alignedSince = 0L
            return Guidance(null, targetX, targetY,
                "Kişi aranıyor… kamerayı yavaşça çevir", false, false, null)
        }

        val dx = face.centerX() - targetX
        val dy = face.centerY() - targetY
        val dist = hypot(dx, dy)
        val threshold = if (alignedSince != 0L) keepThreshold else enterThreshold

        if (dist > threshold) {
            alignedSince = 0L
            val msg = if (abs(dx) > abs(dy)) {
                if (dx > 0) "Kamerayı biraz sağa çevir" else "Kamerayı biraz sola çevir"
            } else {
                if (dy > 0) "Kamerayı biraz aşağı eğ" else "Kamerayı biraz yukarı eğ"
            }
            return Guidance(face, targetX, targetY, msg, false, false, null)
        }

        val now = SystemClock.elapsedRealtime()
        if (alignedSince == 0L) alignedSince = now
        if (now - alignedSince < holdMs) {
            return Guidance(face, targetX, targetY, "Sabit tut…", true, false, null)
        }

        val factor = targetFaceHeight / face.height()
        if (abs(factor - 1f) < 0.12f) {
            return Guidance(face, targetX, targetY, "Mükemmel! Çekebilirsin", true, true, null)
        }

        val desired = (zoom * factor).coerceIn(minZoom, maxZoom)
        if (abs(desired - zoom) < 0.03f) {
            val msg = if (desired >= maxZoom - 0.05f) "Maksimum zoom, biraz yaklaş" else "Mükemmel! Çekebilirsin"
            return Guidance(face, targetX, targetY, msg, true, true, null)
        }
        val next = zoom + (desired - zoom) * 0.15f   // yumuşak zoom
        return Guidance(face, targetX, targetY, "Zoom yapılıyor…", true, false, next)
    }
}
