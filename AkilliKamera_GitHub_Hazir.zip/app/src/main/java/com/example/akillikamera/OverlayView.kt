package com.example.akillikamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class OverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var guidance: Guidance? = null
    private val density = resources.displayMetrics.density

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f * density
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * density; color = Color.argb(160, 255, 255, 255)
    }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f * density; color = Color.argb(200, 255, 214, 0)
    }
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 0, 0, 0) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 16f * density; textAlign = Paint.Align.CENTER
    }

    fun setGuidance(g: Guidance) {
        guidance = g
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val g = guidance ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val color = if (g.aligned) Color.rgb(0, 230, 118) else Color.WHITE
        ring.color = color
        dot.color = color

        val tx = g.targetX * w
        val ty = g.targetY * h
        canvas.drawCircle(tx, ty, 26f * density, ring)
        canvas.drawCircle(tx, ty, 5f * density, dot)

        g.face?.let { f ->
            val r = RectF(f.left * w, f.top * h, f.right * w, f.bottom * h)
            canvas.drawRoundRect(r, 12f * density, 12f * density, box)
            if (!g.aligned) canvas.drawLine(r.centerX(), r.centerY(), tx, ty, arrow)
        }

        // Mesaj
        val tw = text.measureText(g.message)
        val cy = 56f * density
        val pad = 14f * density
        canvas.drawRoundRect(
            w / 2 - tw / 2 - pad, cy - 24f * density, w / 2 + tw / 2 + pad, cy + 12f * density,
            20f * density, 20f * density, pill
        )
        canvas.drawText(g.message, w / 2, cy, text)
    }
}
